drop  table t_student;
create table t_student(roll_no varchar(20) PRIMARY key, full_name varchar(50), date_of_birth date);
insert into t_student(roll_no, full_name, date_of_birth) VALUES
	('R0011', 'Ho Van Cuong 1', '1999/11/11'),
    ('R0022', 'Ho Van Cuong 2', '1999/11/15'),
    ('R0033', 'Ho Van Cuong 3', '1999/11/14'),
    ('R0044', 'Ho Van Cuong 4', '1999/11/13'),
    ('R0055', 'Ho Van Cuong 5', '1999/11/12');
	
	