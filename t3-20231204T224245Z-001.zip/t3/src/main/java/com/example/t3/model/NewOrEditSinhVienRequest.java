package com.example.t3.model;

import javax.validation.constraints.NotBlank;

public class NewOrEditSinhVienRequest {

    @NotBlank(message = "Phai nhap roll")
    private String roll;

    @NotBlank(message = "Phai nhap name")
    private String name;

    @NotBlank(message = "Phai nhap dob")
    private String dob;

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

}
