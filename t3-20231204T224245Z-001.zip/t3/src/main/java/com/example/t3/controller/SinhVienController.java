package com.example.t3.controller;

import com.example.t3.model.NewOrEditSinhVienRequest;
import com.example.t3.repository.SinhVienRepository;
import com.example.t3.model.SinhVien;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import javax.transaction.Transactional;
import javax.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
// co tuong tac DB nen here phai co @Transactional
@Transactional
public class SinhVienController {

    @Autowired
    private SinhVienRepository sinhVienRepository;

    @GetMapping("/")
    public String goHome(Model model) {
        //trong index.jsp nay se hien thi all Sinh vien, nen here phai lay ve all Sinh vien
        List<SinhVien> sinhViens = sinhVienRepository.findAll();
        model.addAttribute("sinhViens", sinhViens);
        return "index"; // webapp/WEB-INF/myviews/index.jsp
    }

    @GetMapping("/xoa")
    public String xoa(@RequestParam(name = "roll") String roll) {
        sinhVienRepository.deleteById(roll);
        //sau khi addnew/update/xoa xong thi quay ve trang index de hien all
//        nhung here phai redirect ve goHome be tren
        return "redirect:/";
    }

    @GetMapping("/chuan-bi-edit")
    public String chuanBiEdit(@RequestParam(name = "roll") String roll, Model model) {
        SinhVien svvv = sinhVienRepository.findById(roll).get();

        String dobVal = svvv.getDob().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        NewOrEditSinhVienRequest svrequest = new NewOrEditSinhVienRequest();
        svrequest.setRoll(svvv.getRoll());
        svrequest.setName(svvv.getName());
        svrequest.setDob(dobVal);
        // ten sv se dung trong edit.jsp va @ModelAttribute trong ham update ben duoi
        model.addAttribute("sv", svrequest);
        return "edit";// webapp/WEB-INF/myviews/edit.jsp
    }

    @GetMapping("/chuan-bi-addnew")
    public String chuanBiAddnew(Model model) {
        NewOrEditSinhVienRequest svrequest = new NewOrEditSinhVienRequest();
        // ten sv se dung trong edit.jsp va @ModelAttribute trong ham update ben duoi
        model.addAttribute("sv", svrequest);
        return "new";// webapp/WEB-INF/myviews/new.jsp
    }

    @PostMapping("/adnew")
    public String adnew(@Valid @ModelAttribute(name = "sv") NewOrEditSinhVienRequest svRequest,
            BindingResult rs,
            Model model) {
        if (rs.hasErrors()) {
            return "new";
        }
        LocalDate dob = LocalDate.parse(svRequest.getDob(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        SinhVien sv = new SinhVien();
        sv.setRoll(svRequest.getRoll());
        sv.setName(svRequest.getName());
        sv.setDob(dob);
        sinhVienRepository.save(sv);
        //sau khi addnew/update/xoa xong thi quay ve trang index de hien all
//        nhung here phai redirect ve goHome be tren
        return "redirect:/";
    }
    @PostMapping("/update")
    public String update(@Valid @ModelAttribute(name = "sv") NewOrEditSinhVienRequest svRequest,
            BindingResult rs,
            Model model) {
        if (rs.hasErrors()) {
            return "edit";
        }
        LocalDate dob = LocalDate.parse(svRequest.getDob(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));

        SinhVien sv = new SinhVien();
        sv.setRoll(svRequest.getRoll());
        sv.setName(svRequest.getName());
        sv.setDob(dob);
        sinhVienRepository.save(sv);
        //sau khi addnew/update/xoa xong thi quay ve trang index de hien all
//        nhung here phai redirect ve goHome be tren
        return "redirect:/";
    }
}
