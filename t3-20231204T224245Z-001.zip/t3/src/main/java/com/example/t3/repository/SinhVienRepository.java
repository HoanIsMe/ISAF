package com.example.t3.repository;

import com.example.t3.model.SinhVien;
import org.springframework.data.jpa.repository.JpaRepository;

// dua vao JpaRepository<ten class, Kieu data cua ID trong class>
//cu the o day: ten class = SinhVien, kieu data cua ID = String vi no la rollNo
public interface SinhVienRepository extends JpaRepository<SinhVien, String> {
}
