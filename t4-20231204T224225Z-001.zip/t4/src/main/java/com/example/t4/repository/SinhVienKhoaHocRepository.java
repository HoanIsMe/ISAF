package com.example.t4.repository;

import com.example.t4.model.SinhVienKhoaHoc;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SinhVienKhoaHocRepository extends JpaRepository<SinhVienKhoaHoc, Integer> {

    // ten param phai co : dung ngay truoc. Ten nay se dung trong @Param nua
    @Query("select a from SinhVienKhoaHoc a where a.studentId = :sinhVienId")
    List<SinhVienKhoaHoc> findBySinhVienId(@Param("sinhVienId") int sinhVienId);
}
