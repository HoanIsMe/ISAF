package com.example.t4.repository;

import com.example.t4.model.KhoaHoc;
import com.example.t4.model.SinhVien;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KhoaHocRepository extends JpaRepository<KhoaHoc, Integer> {

}
