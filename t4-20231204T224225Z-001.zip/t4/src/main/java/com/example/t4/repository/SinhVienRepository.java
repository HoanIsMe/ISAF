package com.example.t4.repository;

import com.example.t4.model.SinhVien;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SinhVienRepository extends JpaRepository<SinhVien, Integer> {
}
