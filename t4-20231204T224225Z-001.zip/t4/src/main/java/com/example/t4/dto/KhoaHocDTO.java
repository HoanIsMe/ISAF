package com.example.t4.dto;

import java.util.Date;

public class KhoaHocDTO {
    private String tenKhoaHoc;
    private int khoaHocDuration;
    private Date enrollmentDate;

    public String getTenKhoaHoc() {
        return tenKhoaHoc;
    }

    public void setTenKhoaHoc(String tenKhoaHoc) {
        this.tenKhoaHoc = tenKhoaHoc;
    }

    public int getKhoaHocDuration() {
        return khoaHocDuration;
    }

    public void setKhoaHocDuration(int khoaHocDuration) {
        this.khoaHocDuration = khoaHocDuration;
    }

    public Date getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(Date enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }
}