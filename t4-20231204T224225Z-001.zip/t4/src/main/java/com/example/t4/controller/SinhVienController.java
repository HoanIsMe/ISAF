package com.example.t4.controller;

import com.example.t4.dto.KhoaHocDTO;
import com.example.t4.dto.SinhVienDTO;
import com.example.t4.model.KhoaHoc;
import com.example.t4.model.SinhVien;
import com.example.t4.model.SinhVienKhoaHoc;
import com.example.t4.repository.KhoaHocRepository;
import com.example.t4.repository.SinhVienKhoaHocRepository;
import com.example.t4.repository.SinhVienRepository;
import jdk.jfr.Frequency;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class SinhVienController {
    @Autowired
    private SinhVienRepository sinhVienRepository;

    @Autowired
    private KhoaHocRepository khoaHocRepository;

    @Autowired
    private SinhVienKhoaHocRepository sinhVienKhoaHocRepository;

    @GetMapping
    public String goHome(Model model) {
        List<SinhVienDTO> response = new ArrayList<>();
        List<SinhVien> sinhViens = sinhVienRepository.findAll();
        for (SinhVien sv : sinhViens) {
            SinhVienDTO sinhVienDTO = new SinhVienDTO();
            sinhVienDTO.setId(sv.getId());
            sinhVienDTO.setName(sv.getName());
            sinhVienDTO.setLopHoc(sv.getClassName());

            List<KhoaHocDTO> khoaHocDTOs = new ArrayList<>();

            List<SinhVienKhoaHoc> sinhVienKhoaHocs = sinhVienKhoaHocRepository.findBySinhVienId(sv.getId());
            for(SinhVienKhoaHoc svKhoaHoc : sinhVienKhoaHocs) {
                KhoaHoc khoHoc = khoaHocRepository.findById(svKhoaHoc.getCourseId()).get();

                KhoaHocDTO khoaHocDTO = new KhoaHocDTO();
                khoaHocDTO.setTenKhoaHoc(khoHoc.getName());
                khoaHocDTO.setKhoaHocDuration(khoHoc.getDuration());
                khoaHocDTO.setEnrollmentDate(svKhoaHoc.getEnrollmentDate());

                khoaHocDTOs.add(khoaHocDTO);
            }
            sinhVienDTO.setKhoaHocs(khoaHocDTOs);

            response.add(sinhVienDTO);
        }

        model.addAttribute("sinhViens", response);
        return "index";
    }
    @GetMapping("/chuan-bi-assign")
    public String chuanBiAssign(@PathParam("id") int id, Model model){
        SinhVien sv = sinhVienRepository.findById(id).get();
        model.addAttribute("svId", sv.getId());
        model.addAttribute("svName", sv.getName());

        List<KhoaHoc> khoaHocs = khoaHocRepository.findAll();
        model.addAttribute("khoaHocs", khoaHocs);
        return "assign";
    }

    @PostMapping("/AssignDi")
    public String assignDi(HttpServletRequest rq){
        String svId = rq.getParameter("svId");
        String khId = rq.getParameter("khId");

        SinhVienKhoaHoc svKh = new SinhVienKhoaHoc();
        svKh.setCourseId(Integer.parseInt(khId));
        svKh.setStudentId(Integer.parseInt(svId));
        svKh.setEnrollmentDate(new Date());

        sinhVienKhoaHocRepository.save(svKh);

        return "redirect:/";
    }
}
